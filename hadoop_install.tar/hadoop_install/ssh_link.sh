#!/bin/bash
#link every computer 
#张孟辉 2046459994@qq.com
master=`cat -n /root/conf|grep master|sed s'/^.*master=//g'`
slavers=`cat -n /root/conf|grep slaver|sed s'/^.*slaver=//g'`
password=`cat -n /root/conf|grep password|sed s'/^.*password=//g'`
localhost=`ifconfig | sed -n '2p'|sed 's/^.*inet //g'|sed 's/ netmask.*//g'`
slaver_number=0
#source /root/hadoop_install.sh
for slave_tempt in $slavers
do
slaver_number=$(($slaver_number+1))
done
expect -c "set timeout -1;
spawn ssh-keygen;
expect {
{* in which to save the key *} {send -- \r;exp_continue}
{*(empty for no passphrase)*} {send -- \r;exp_continue}
{*same passphrase again*} {send -- \r;exp_continue}
eof {exit 0;}
}";
expect -c "set timeout -1;
spawn ssh-copy-id root@$master;
expect {
{*(yes/no)*} {send -- yes\r;exp_continue}
{*password*} {send -- $password\r;exp_continue}
eof {exit 0;}
}";
function testfile(){
#if [$master=$localhost];
#then
[ -f /root/.ssh/authorized_keys ] && row_number=`cat /root/.ssh/authorized_keys | wc -l`||row_number=0
}
function ssh_all(){
for slave in $slavers
do
expect -c "set timeout -1;
spawn scp /root/.ssh/authorized_keys root@$slave:/root/.ssh/;
expect {
{*(yes/no)*} {send -- yes\r;exp_continue}
{*password*} {send -- $password\r;exp_continue}
eof {exit 0;}
}";
done
}
if [ $master == $localhost ]
then
testfile
while [ $(($slaver_number+1)) != $row_number ]
do
echo '正在检查authorized_keys这个文件是否接受收了全部公钥，十分钟之后还是这句话，请contr+c,终止程序，检查节点是否正常'
testfile
sleep 5
done
echo '接收完成，将要执行分发任务，请耐心等待'
ssh_all
fi
echo '恭喜你，安装完成'
