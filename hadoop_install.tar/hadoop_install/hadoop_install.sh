#!/bin/bash
# it's a script to install hadoop
tar zxvf jdk-7u79-linux-x64.tar.gz
sed -i '9a export JAVA_HOME=/root/jdk1.7.0_79' /etc/profile
sed -i '10a export CLASSPATH=.:$JAVA_HOME/jre/lib/rt.jar:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar' /etc/profile
sed -i '11a export PATH=$PATH:$JAVA_HOME/bin' /etc/profile
sed -i '12a export PATH=$PATH:/root/hadoop-2.8.0/bin:/root/hadoop-2.8.0/sbin' /etc/profile
source /etc/profile
tar zxvf hadoop-2.8.0.tar.gz
mkdir tmp dfs
mkdir dfs/data dfs/name
cd ./hadoop-2.8.0/etc/hadoop/
mv mapred-site.xml.template mapred-site.xml
sed -i '/^export JAVA_HOME=${JAVA_HOME}/ s/JAVA_HOME=${JAVA_HOME}/JAVA_HOME=\/root\/jdk1.7.0_79/g' hadoop-env.sh
sed -i '/^#.*export JAVA_HOME=.*/ s/^.*$/export JAVA_HOME=\/root\/jdk1.7.0_79/g' yarn-env.sh
sed -i '/^#.*export JAVA_HOME=.*/ s/^.*$/export JAVA_HOME=\/root\/jdk1.7.0_79/g' mapred-env.sh
sed -i '/<.*configuration>/d' core-site.xml
cat >> core-site.xml << EOF
<configuration>
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://$master:9000</value>
    </property>
    <property>
        <name>hadoop.tmp.dir</name>
        <value>file:/root/tmp</value>
    </property>
    <property>
        <name>io.file.buffer.size</name>
        <value>131702</value>
    </property>
</configuration>
EOF
sed -i '/<.*configuration>/d' hdfs-site.xml
cat >> hdfs-site.xml << EOF
<configuration>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>file:/root/dfs/name</value>
    </property>
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>file:/root/dfs/data</value>
    </property>
    <property>
        <name>dfs.replication</name>
        <value>2</value>
    </property>
    <property>
        <name>dfs.namenode.secondary.http-address</name>
        <value>$localhost:9001</value>
    </property>
    <property>
    <name>dfs.webhdfs.enabled</name>
    <value>true</value>
    </property>
</configuration>
EOF
sed -i '/<.*configuration>/d' mapred-site.xml
cat >> mapred-site.xml << EOF
<configuration>
    <property>
        <name>mapreduce.framework.name</name>
        <value>yarn</value>
    </property>
    <property>
        <name>mapreduce.jobhistory.address</name>
        <value>$localhost:10020</value>
    </property>
    <property>
        <name>mapreduce.jobhistory.webapp.address</name>
        <value>$localhost:19888</value>
    </property>
</configuration>
EOF
sed -i '/<.*configuration>/d' yarn-site.xml
cat >> yarn-site.xml << EOF
<configuration>
    <property>
        <name>yarn.nodemanager.aux-services</name>
        <value>mapreduce_shuffle</value>
    </property>
    <property>
        <name>yarn.nodemanager.auxservices.mapreduce.shuffle.class</name>
        <value>org.apache.hadoop.mapred.ShuffleHandler</value>
    </property>
    <property>
        <name>yarn.resourcemanager.address</name>
        <value>$master:8032</value>
    </property>
    <property>
        <name>yarn.resourcemanager.scheduler.address</name>
        <value>$master:8030</value>
    </property>
    <property>
        <name>yarn.resourcemanager.resource-tracker.address</name>
        <value>$master:8031</value>
    </property>
    <property>
        <name>yarn.resourcemanager.admin.address</name>
        <value>$master:8033</value>
    </property>
    <property>
        <name>yarn.resourcemanager.webapp.address</name>
        <value>$master:8088</value>
    </property>
    <property>
        <name>yarn.nodemanager.resource.memory-mb</name>
        <value>4096</value>
    </property>
</configuration>
EOF
if [ $master == $localhost ]
then
for slave_i in $slavers
do
sed -i '$ a\'$slave_i'' slaves
done
fi
sed -i '/localhost/d' slaves
#echo 'zhang2' >> slaves
# slave important!!!!


